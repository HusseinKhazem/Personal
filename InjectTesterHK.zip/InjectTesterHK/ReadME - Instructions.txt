<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
<!! HELLO, This tools has been coded by Hussein KH, and his in its BETA Stage. IMPORTANT: THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY HUSSEIN KH IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE DONE BY USING THIS THIS TOOL.
-------------------------------------------------------------------------------------!
CHECK MY WEBSITE FOR MORE TOOLS AND TRICKS, www.lebaneseprodigy.com, HUSSEIN KHAZEM. 
-------------------------------------------------------------------------------------!

This tool does not Exploit The sql database, this tool will only test the website if its Exploitable or not.


Requirements to run this tool:

-Chrome Browser ===>https://www.google.com/chrome/?brand=YTUH&gclsrc=aw.ds&gclid=CjwKCAjw_uGmBhBREiwAeOfsd8ADuQCyjOEU2uZGO6OlJlEcf1iI2kc6sCdErBphdACpQc6ZfviHQhoCSD4QAvD_BwE
-Chrome Driver ===> https://chromedriver.storage.googleapis.com/index.html

-List Of Potential Sql Injectable Websites, You can get some dorks on google, figure out a list, or download complete lists from google.
(Each Website should be on a separate line, Please Include the dork in the urls.)

======================================================================================


Run The Tool As Administrator,

-You will be prompted to specify path for the Chrome Driver, specify the path only for the folder where the chrome driver is extracted.

-Specify the Path/Name.txt, of the List you pre configured. Must be inside a txt file.

Choose Y to continue The test.

Wait for the CLi to do its thing, The tool will automatically close when its done, if everything is done correctly you will find a results.txt which has the results of your list in the same dir as the tool is.


Happy Hacking! Hussein Khazem. All Rights reserved 
---------------------------------------------------------------------------------------
                 uuuuuuu
             uu$$$$$$$$$$$uu
          uu$$$$$$$$$$$$$$$$$uu
         u$$$$$$$$$$$$$$$$$$$$$u
        u$$$$$$$$$$$$$$$$$$$$$$$u
       u$$$$$$$$$$$$$$$$$$$$$$$$$u
       u$$$$$$$$$$$$$$$$$$$$$$$$$u
       u$$$$$$"   "$$$"   "$$$$$$u
       "$$$$"      u$u       $$$$"
        $$$u       u$u       u$$$
        $$$u      u$$$u      u$$$
         *$$$$uu$$$   $$$uu$$$$*
          *$$$$$$$*   *$$$$$$$*
            u$$$$$$$u$$$$$$$u
             u$*$*$*$*$*$*$u
  uuu        $$u$ $ $ $ $u$$       uuu
 u$$$$        $$$$$u$u$u$$$       u$$$$
  $$$$$uu      "$$$$$$$$$"     uu$$$$$$      
u$$$$$$$$$$$uu    """""    uuuu$$$$$$$$$$
$$$$"""$$$$$$$$$$uuu   uu$$$$$$$$$"""$$$"
 """      ""$$$$$$$$$$$uu ""$"""
           uuuu ""$$$$$$$$$$uuu
  u$$$uuu$$$$$$$$$uu ""$$$$$$$$$$$uuu$$$
  $$$$$$$$$$""""           ""$$$$$$$$$$$"
   "$$$$$"                      ""$$$$""
     $$$"                         $$$$"